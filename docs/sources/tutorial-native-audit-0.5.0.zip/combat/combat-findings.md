# 튜토리얼 전투 정적 감사

제공 APK 2.19.6.0의 arm64 libgame.so와 복호화된 tuto1/tuto9만 조사했다. Android 실행, 원본 서버 접속, 저장소 runtime/docs 수정은 하지 않았다. 상세 기계 판독 근거는 combat-native-proof.json에 있다.

## 피해·부대: 확정과 미확정

- **확정된 피해 예외는 아군 생존 보호다.** BattleUnit::decHp(0x111df28)는 평상시처럼 HP에서 피해를 뺀 뒤, isTutoPlaying이고 getType()==1이면 HP를 최소 1로 만든다(0x111dfbc–0x111dfdc). PlayerUnit::getType(0x115c230)는 1, EnemyUnit::getType(0x11552e8)는 2다. 따라서 이 보호는 적의 HP에 적용하지 않는다.
- 유도 공격의 적 HP 1/3, 마지막 입력 즉사, BB 모든 적 즉사, 리더 HP 58%/23% 설정은 현재 확인한 원본 코드에서 근거를 찾지 못했다. MissionScene::scriptEvent의 세 유도 공격은 PlayerParty::touchPlayer(unit,0) → PlayerUnit::touch(0)이라는 정상 입력 경로를 호출한다.
- BattleUnit::procAttack은 calcAttack을 호출한다(0x10ffa88). 이후 UserDebugInfo::isDebugMode(0)가 참일 때만 존재하는 별도 디버그 분기가 있으므로, 그 강제 피해 분기를 튜토리얼 동작으로 오인하면 안 된다.
- 0x1040000..0x1168000 범위에서 UserInfo/BattleManager의 Tuto 이름 메서드로 향하는 직접 B/BL을 조사했다. decHp 보호 외에 일반 damage 계산 메서드에서 직접 튜토리얼 API 호출은 나오지 않았다. 가상 호출이나 모든 외부 데이터 경로의 부재를 증명하는 감사는 아니다.
- TutorialStepScene::initPartyStatus(0x1b938a4)는 chapter1에서 **기존 소유 부대**를 읽어 리더, 비리더 불, 비리더 번개를 찾고 위치 2/0/1에 재배치한다. 새 지원 유닛 생성, ID10030/40030 고정, 레벨1/2 설정은 이 함수에 없다. 해당 서버 초기 부대 payload를 확보하지 못했으므로 지원 유닛의 동일 버전 재현은 미완료다.

## 비동기 큐 연결에 보존할 동작

1. unit_stop_atk는 공격 완료가 아니다. MissionScene::checkTutorialState(0x1803b74–0x1803bac)는 초기값0인 counter가5 이상이면 script state41로 돌아간다. updateEvent가 먼저 이 함수를 호출하므로 5번의 전투 업데이트 뒤 여섯 번째 검사에서 복귀한다. 고정된 83.333ms로 단정할 원본 FPS 근거는 이 조사에서 얻지 못했다.
2. PARAM24는 EdgeAnimeList::pauseAnime(분기0xfc88a4), PARAM25는 resumeAnime(0xfc8030)다. 첫 두 유닛의 공격을 짧게 시작한 채 안내 중 멈추고 다음 유닛 입력에서 함께 재개한다.
3. active_action_end는 선택 유닛 isEndAction, player/enemy_turn_start는 해당 party isMyTurn, *_turn_end는 isMyTurn에 isTurnEndwait를 함께 검사한다. battle_end는 scene state0x1a, treasure_start는0xb를 검사한다.
4. PARAM100의 세 번째 값 none은 이벤트를 지우지 않는다(0xfc7c24–34). 새 값만 UserInfo::setTutoEventID에 쓴다. tuto_drop_heart가 활성인 동안 후속 none에서도 유지된다. 각 MissionScene::scriptEvent 종료 시 해당 drop 이벤트면 once flag를 리셋한다(0x18190b4).
5. 튜토리얼 하트/BC drop callback은 활성 이벤트의 첫 확률 검사에서100%, 이후0%다. 정상35% 확률을 튜토리얼에서도 계속 쓰는 구조가 아니다.

## 결정·회복

- 마법 결정은 native에서 정확히15개 생성한다(0x1818808). tuto9:114–119는 생성 → 1.5초 → getAll → 1.5초다.
- getAll(0x10474a8)은 이동을 시작한다. 실제 BB 증가 시점은 exitItemMove(0x10444f0)다.
- tuto_get_battle_crystal이면 15개 모두 position2(리더)를 대상으로 한다(0x1044664–70). 전원 BB 최대 주입이 아니다.
- addBattleCrystal(0x1134fa0)는 기본100 내부 게이지단위와 passive/buff 보정으로 incSkillGage를 부른다. 해당 경로에 튜토리얼 max-fill은 없다. 현재 웹 기본 스타터들의 cost15는 정규화한 결정15개×1과 맞는다. 이 수치의 동일 버전 서버 cost 일치까지 입증한 것은 아니다.
- 이동 동작은 랜덤0..0.5초 지연 +0.6초 MoveTo, 각각 getSpeedFactor로 나누며 EaseIn1.2를 적용한다(0x1043500). 도착 callback에서 수령한다.
- 하트는 부상 중 살아 있는 아군 중 무작위 대상, 없으면 활성 아군 무작위다(0x10b85ec). 회복량은 getTotalHeal / random(3,4.2), 최소1에 passive보정을 적용하고 도착 때 DamageList::setRecover를 등록한다. 고정 REC×0.35는 원본식으로 확인되지 않는다.
- chapter1 적의 타깃은 position2로 강제된다(0x18193f4). 리더만 다친 상황에서 하트가 리더에게 가는 것은 이 조건들의 결과다.

## 체크리스트 한계

T06은 동일 버전 서버 부대·적 스탯·보상을 확보하지 못했으므로 미완료로 남겨야 한다. T07은 위 큐/중단/수령 시점을 구현하면 해당 부분만 확인할 수 있다. 이동10프레임, HP 카운터 곡선, 동일 기기 FPS, 실제 앱 캡처와의 모든 프레임 일치는 이번 근거에서 확정하지 못했다. T08/T09 전체 완료의 근거로 확대하지 않는다.

## 근거 파일

- combat-native-proof.json: 주소, 사실, 한계, 근거 파일 목록
- tutorial-damage-overrides.txt + action-start.txt: HP1 보호와 정상 입력 경로
- battle-tutorial-xrefs.txt: 직접 튜토리얼 API 참조 범위 조사
- party-initialization.txt: 소유 부대 재배치
- tutorial-state.txt + battle-loop.txt: 대기 상태와 업데이트 순서
- crystal.txt + crystal-receive.txt: 생성 대상과 수령·이동
- script-source-excerpts.txt + script-native-excerpts.txt: 원문 지시와 PARAM 해석
- virtual-table-resolution.txt: 가상 호출 대상의 ELF relocation 확인
